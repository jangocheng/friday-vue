<template>
<div class="myMages">
		<p>我的消息</p>
		<div class="magesCont">
			<p>你的货物已发货</p>
			<span>我以为要是唱的用心良苦,你总会对我多点在乎.我以为虽然爱情已成往事,千言万语说出来可以互相安抚.期待你感动,真实的我们难相处.写词的让我,唱出你要的幸福.谁曾经感动,分手的关头才懂得.离开排行榜更铭心刻骨.我已经相信有些人我永远不必等,所以我明白在灯火阑处为什么会哭.你不会相信,嫁给我明天有多幸福.只想你明白,我心甘情愿爱爱爱爱到要吐.那是醉生死才能熬成的苦,爱如潮水,我忘了我是谁,至少还有你哭.我想唱一首歌给我们祝福,唱完了我会一个人祝我愿意试着了解从此以后.拥挤的房间一个人的心有多孤独.让我断了气铁了心爱的过火,一回头就找到出路.让我成为了无情的k歌之王.麦克风都让我征服,想不到你若无其事的说:"这样滥情,何苦?"我想来一个吻别作为结束,想不到你只说我不许哭,不该我领悟!</span>
		</div>
</div>
</template>

<script>
</script>

<style>
		.myMages {
		float: right;
		width: 1085px;
		height: 625px;
		border: 1px solid lightgray;
	}
	
	.myMages>p {
		line-height: 55px;
		width: 100%;
		font-size: 20px;
		padding-left: 20px;
		border-bottom: 1px solid lightgray
	}
	.magesCont{
		width: 90%;
		margin-left: 5%;
		margin-right: 5%;
		
	}
		.magesCont>p{
			color:#498e3d;
			font-size:20px;
			margin-top: 50px;
			text-align: center;
			margin-bottom: 20px;
		}
</style>