<template>
	<div class="myCollection">
		<p>我的收藏</p>
		<div class="collectionCont">
			<div class="collContDaf">
			<img src="../../img/person/ware.png" alt=""/>
			<p class="wareName">你我山前没相见,山后别相逢</p>
			<p class="wareTitle">你可知道你的名字解释了我的一生</p>
			<span class="warePrice"><em class="nowPrice">¥28.80</em><em class="originalPrice">¥40.00</em><em class="carImg"></em></span><br />
			<span class="colDaf">已失效</span>
			</div>
			<div class="collContSue">
			<img src="../../img/person/ware.png" alt=""/>
			<p class="wareName">你我山前没相见,山后别相逢</p>
			<p class="wareTitle">你可知道你的名字解释了我的一生</p>
			<span class="warePrice"><em class="nowPrice">¥28.80</em><em class="originalPrice">¥40.00</em><em class="carImg"></em></span><br />
			<span class="colButton">取消收藏</span>
			</div>
		</div>
	</div>
</template>

<script>
</script>

<style>
	.myCollection {
		float: right;
		width: 1085px;
		height: 625px;
		border: 1px solid lightgray;
	}
	
	.myCollection>p {
		line-height: 55px;
		width: 100%;
		font-size: 20px;
		padding-left: 20px;
		border-bottom: 1px solid lightgray
	}
	.collectionCont>div{
		width: 305px;
		height: 480px;
		border: 1px solid lightgray;
		float: left;
		margin-top: 40px;
		margin-left: 45px;
		
	}
	.collectionCont>div>img{
		margin-top: 40px;
		width: 261px;
		height: 253px;
		border: 1px solid gray;
		margin-left: 20px;
	}
	.wareName{
		margin-top: 20px;
		font-size: 20px;
		margin-left: 20px;
	}
	.wareTitle{
		margin-left: 20px;
		margin-top: 5px;
		font-size:14px;
	}
	.warePrice{
		display: inline-block;
		padding-left: 20px;
		margin-top: 10px;
	}
	.nowPrice{
		font-size:26px;
		color: rgb(255,137,137);
	}
	.originalPrice{
		text-decoration: line-through;
		padding-left: 10px;
		padding-right:80px ;
	}
	.carImg{
		display: inline-block;
		width: 34px;
		height: 30px;
		background: url(../../img/person/shopCar.png);
	}
		.colDaf{
			display: inline-block;
			width: 150px;
			height: 35px;
			background:lightgray;
			text-align: center;
			line-height: 35px;
					margin-left:77px ;
					border-radius: 20px;
						color: white;
		}
		.colButton{
				display: inline-block;
			width: 150px;
			height: 35px;
			background:rgb(75,148,61);
			text-align: center;
				line-height: 35px;
				margin-left:77px ;
					border-radius: 20px;
					color: white;
		}
</style>